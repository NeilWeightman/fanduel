package com.fanduel.strings;

import java.util.List;
import java.util.Locale;

public class StringTester {
    public static void main(String[] args) {
        StringBuilder anotherName = new StringBuilder("Tuco Ramirez");
        anotherName.delete(0,4);
        anotherName.insert(0, "Dominic");
        System.out.println(anotherName);
        String dom = anotherName.toString();
        System.out.println(dom.substring(8, 11)); // substring 2-int version returns the characters
                                                  // from firstIndex to secondIndex-1 inclusive
        String s1 = "James, Bayo, Laurie";
        String[] myArray = s1.split(", ");
        System.out.println(myArray[1]);
        String[] names = {"Jemima", "James", "Bayo"};
        // sort the array in alphabetical order
        // print out the unsorted array, sort it, then print the sorted array
        // bubblesort
        // what about case? what about empty strings? what if the array is empty?

    }
    // new function isPalindrome(String) return true if the string is a palindrome
    // false if the string not a palindrome or is empty
    // what about case issues?

}
