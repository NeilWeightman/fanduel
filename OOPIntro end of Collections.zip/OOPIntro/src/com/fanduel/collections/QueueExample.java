package com.fanduel.collections;

import java.util.ArrayDeque;
import java.util.List;

public class QueueExample {
    public static void main(String[] args) {
        ArrayDeque myQueue = new ArrayDeque(List.of("Mexico", "Portugal"));
        myQueue.add("Australia");
        myQueue.add("India");
        myQueue.add("Bolivia");
        myQueue.addFirst("Japan");
        System.out.println(myQueue);
        System.out.println(myQueue.removeLast());
        System.out.println(myQueue);
    }
}
