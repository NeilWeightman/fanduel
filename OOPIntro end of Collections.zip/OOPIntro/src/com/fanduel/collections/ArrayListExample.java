package com.fanduel.collections;

import com.fanduel.oop.Car;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample {
    public static void main(String[] args) {
        var myList = new ArrayList<String>(List.of("London", "Birmingham", "Bath",
                "Cardiff", "Glasgow", "Cardiff"));
//        myList.add(new Car());
        System.out.println(myList);
        myList.add(1, "Leeds");
        myList.remove(4);
        String cityName = myList.get(4);
        System.out.println(cityName);
        for (String city: myList){
            System.out.println(city);
        }

    }
}
