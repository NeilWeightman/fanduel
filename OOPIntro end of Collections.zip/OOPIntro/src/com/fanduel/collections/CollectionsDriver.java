package com.fanduel.collections;

import java.util.Scanner;

public class CollectionsDriver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String lineOfText;
        do {
            lineOfText = scanner.nextLine();
            System.out.println(lineOfText);
        } while (!lineOfText.equals("x"));
    }
}
