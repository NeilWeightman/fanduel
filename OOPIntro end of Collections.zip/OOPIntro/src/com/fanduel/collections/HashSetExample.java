package com.fanduel.collections;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HashSetExample {
    public static void main(String[] args) {
        HashSet<String> mySet = new HashSet<>(List.of("London", "Birmingham", "Bath",
                "Cardiff", "Glasgow", "Birmingham"));
        System.out.println(mySet);
        mySet.add("Cardiff");
        System.out.println(mySet);
    }
}
