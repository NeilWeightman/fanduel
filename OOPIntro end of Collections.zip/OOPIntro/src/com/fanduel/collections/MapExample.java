package com.fanduel.collections;

import com.fanduel.inheritance.Shirt;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
    public static void main(String[] args) {
        Shirt s1 = new Shirt(12.99, 'M', 'G');
        int s1Id = s1.getId();
        System.out.println(s1);
        HashMap<Character, Shirt> myMap = new HashMap<>();
        myMap.put(Character.valueOf(s1.getColorCode()), s1);
        System.out.println(myMap);
        Shirt s2 = new Shirt(199.99, 'L', 'B');
        myMap.put(Character.valueOf(s2.getColorCode()), s2);
        Shirt s3 = new Shirt(1.99, 'S', 'B');
        myMap.put(Character.valueOf('F'), s3);
        System.out.println(myMap);
        Shirt retrievedShirt = myMap.get(Character.valueOf('F'));
        System.out.println(retrievedShirt);
        System.out.println(myMap.values());
        for (Character nextKey: myMap.keySet()){
            System.out.println(myMap.get(nextKey));
        }
        for (Shirt nextShirt: myMap.values()){
            System.out.println(nextShirt);
        }
        for (Map.Entry<Character,Shirt> nextEntry: myMap.entrySet()){
            System.out.println(nextEntry);
        }
    }
}
