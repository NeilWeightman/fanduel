package com.fanduel.oop;

import javax.swing.*;

public class Car extends Vehicle {
    // 4 levels of access public, private, protected, "default"

    // all instance variables should normally be private
    private int age;
    private double engineSize;
    private int numberOfDoors;

    // all instance methods should probably be public
    public Car(String ownerName, int age, String colour,
               String modelName, double engineSize, int numberOfDoors){
        super(ownerName, colour, modelName, 4);
        this.age = age;
        this.engineSize = engineSize;
        this.numberOfDoors = numberOfDoors;
    }

    public Car(String ownerName, String modelName, double engineSize) {
        this(ownerName, 0, "Unknown", modelName, engineSize, 4);
    }

    public Car() {
        super("dummy", "blank",
              "unknown", 0);
    }

    public String toString() {
        String description = super.toString()
                + " " + engineSize + " litre";
        return description;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getEngineSize() {
        return engineSize;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    public void setEngineSize(double newEngineSize){
        if (newEngineSize <= 0.0)
            ;// report an error
        else
            engineSize = newEngineSize;
    }
}
