package com.fanduel.oop;

public class Dealership {
    public static void main(String[] args) {
        // instantiating the Car class by using the constructor
        Car laurasCar = new Car("Laura", 16, "Black",
                "Clio", 1.2, 2);
        System.out.println(laurasCar);
        laurasCar.setEngineSize(6.9);
        laurasCar.setColour("Green");
        System.out.println(laurasCar);
        System.out.println(laurasCar.getAge());
        Car lauriesCar = new Car("Laurie", "Civic", 1.6);
        System.out.println(lauriesCar);
        lauriesCar.setEngineSize(-2.3);
        System.out.println(lauriesCar);
        Boat neilsBoat = new Boat("Neil", "White",
                "Cheap Rowing Boat",2);
        neilsBoat.setHasSundeck(true);
        System.out.println(neilsBoat);
        System.out.println(neilsBoat.hashCode());
    }

}
