package com.fanduel.inheritance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class ShoppingCart {
    public static void main(String args[]){ 
	// Instantiate a Shirt object and call display() on the object reference
        Shirt shirt = new Shirt(25.99, 'M', 'P');
        shirt.display();

    }
}    
