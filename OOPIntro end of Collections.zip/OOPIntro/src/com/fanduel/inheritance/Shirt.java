package com.fanduel.inheritance;

import java.util.Objects;

public class Shirt extends Item {
    private char size;
    private char colorCode;

    @Override
    public String toString() {
        return "Shirt {" +
                "size=" + size +
                ", colorCode=" + colorCode +
                ", price=" + getPrice() +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Shirt shirt = (Shirt) o;
        return size == shirt.size && colorCode == shirt.colorCode;
    }

    @Override
    public int hashCode() {
        return Objects.hash(size);
    }

    public Shirt(double price, char size, char colorCode){
        super ("Shirt", price);
        this.size = size;
        this.colorCode = colorCode;
    }

    public char getSize() {
        return size;
    }

    public void setSize(char size) {
        this.size = size;
    }

    public char getColorCode() {
        return colorCode;
    }

    public void setColorCode(char colorCode) {
        this.colorCode = colorCode;
    }
}
