package com.fanduel.bank;

public interface Closeable {
    public void close();
}
