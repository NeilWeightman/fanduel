package com.fanduel.bank;

import java.util.ArrayList;

public abstract class Account {
    private String accountNumber;
    private String accountType;
    private double balance;
    private ArrayList<Transaction> transactionHistory;
    private String accountHolderName;

    public Account(String accountNumber, String accountType, String accountHolderName) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0; // zero balance initially
        this.transactionHistory = new ArrayList<>(); // no transactions to begin with
    }

    public boolean applyTransaction(Transaction trans){
        if(trans.getTransactionType().equals("credit")){
            balance = balance + trans.getTransactionAmount();
        } else if (trans.getTransactionType().equals("debit")){
            balance = balance - trans.getTransactionAmount();
        } else {
            return false;
        }
        transactionHistory.add(trans);
        return true;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public double getBalance() {
        return balance;
    }

    public ArrayList<Transaction> getTransactionHistory() {
        return transactionHistory;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accountNumber='" + accountNumber + '\'' +
                ", accountType='" + accountType + '\'' +
                ", balance=" + balance +
                ", transactionHistory=" + transactionHistory +
                ", accountHolderName='" + accountHolderName + '\'' +
                '}';
    }
    public abstract void close();
}
