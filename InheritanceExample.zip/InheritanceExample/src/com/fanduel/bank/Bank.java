package com.fanduel.bank;

import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class Bank {
    public static void main(String[] args) {
//        Account account1 = new Account("00000001", "Cheque",
//            "Bill");
//        System.out.println(account1);
//        Transaction t1 = new Transaction("credit", new Date(),
//                1000.00, "Initial transfer");
//        System.out.println(t1);
//        account1.applyTransaction(t1);
//        System.out.println(account1);

        SavingsAccount account2 = new SavingsAccount("00000002", "Savings",
                "Bob", 0.0001);
        Transaction t2 = new Transaction("credit", new Date(),
                50000.00, "Initial transfer");
        account2.applyTransaction(t2);
        System.out.println(account2);
        account2.applyInterest();
        System.out.println(account2);
        Transaction t3 = new Transaction("debit", new Date(),
                60000.00, "Clear out the account");
        account2.applyTransaction(t3);
        System.out.println(account2);

        // Account acc01 = new Account();
        SavingsAccount acc02 = new SavingsAccount("0002",
                "savings", "Jakob", 0.01);
        RewardAccount acc03 = new RewardAccount("0003",
                "reward", "Charles");

        ArrayList<Account> accountList = new ArrayList<>();
        Random r = new Random();
        for(int i = 0; i < 10; i++){
            if(r.nextBoolean()){
                accountList.add(new SavingsAccount("000",
                        "s", "X", 0.1));
            } else {
                accountList.add(new RewardAccount("999",
                        "r", "Y"));
            }
        }
        for(Account account: accountList){
            System.out.println(account.toString());
            account.close();
            // RISKY cast from one type (Account) to another (SavingsAccount)
            SavingsAccount sAccount = (SavingsAccount)account;
            double interest = sAccount.getInterestRate();
        }
        Branch b = new Branch();

        Closeable thingToClose = acc02;
        thingToClose.close();



    }
}
