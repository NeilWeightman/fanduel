package com.fanduel.bank;

public class Branch implements Closeable {
    @Override
    public void close() {
        System.out.println("This branch is closed");
    }
}
