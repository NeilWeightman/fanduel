package com.fanduel.bank;

import java.util.Date;

public class SavingsAccount extends Account implements Closeable, Comparable {
    private double interestRate;
    private boolean isOpen = true;
    public SavingsAccount(String accountNumber, String accountType, String accountHolderName) {
        super(accountNumber, accountType, accountHolderName);
    }

    public SavingsAccount(String accountNumber, String accountType, String accountHolderName, double interestRate) {
        super(accountNumber, accountType, accountHolderName);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public String toString() {
        return "SavingsAccount{" +
                "interestRate=" + interestRate + ' ' + super.toString() +
                '}';
    }

    @Override
    public void close() {
        // close my savings account
        System.out.println("Savings account closed");
        isOpen = false;
    }

    public void applyInterest(){
        Transaction interest = new Transaction("credit", new Date(),
                interestRate * getBalance(), "Interest");
        applyTransaction(interest);
    }

    @Override // annotation
    public boolean applyTransaction(Transaction trans) {
        if(trans.getTransactionAmount() > getBalance()
                && trans.getTransactionType().equals("debit"))
            return false;
        if(!isOpen)
            return false;
        return super.applyTransaction(trans);
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
