package com.fanduel.bank;

import java.util.AbstractList;

public class AbstractDriver {
    public static void main(String[] args) {
        MySpecialList list = new MySpecialList();
//        AbstractList list2 = new AbstractList();
    }
}
