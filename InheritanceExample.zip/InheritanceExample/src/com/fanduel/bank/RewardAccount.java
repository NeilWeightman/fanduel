package com.fanduel.bank;

public class RewardAccount extends Account {
    public RewardAccount(String accountNumber, String accountType, String accountHolderName) {
        super(accountNumber, accountType, accountHolderName);
    }

    @Override
    public void close() {
        System.out.println("Reward account closed");
    }

    @Override
    public String toString() {
        return "RewardAccount{}";
    }
}
