package com.fanduel.bank;

import java.util.AbstractList;

public class MySpecialList extends AbstractList {
    @Override
    public Object get(int index) {
        return null;
    }

    @Override
    public int size() {
        return 0;
    }
}
