package com.fanduel.oop;

public class Vehicle {
    protected String ownerName;
    private String colour;
    private String modelName;
    private int numberOfSeats;

    public Vehicle(String ownerName, String colour, String modelName, int numberOfSeats) {
        this.ownerName = ownerName;
        this.colour = colour;
        this.modelName = modelName;
        this.numberOfSeats = numberOfSeats;
    }

    @Override
    public String toString() {
        return ownerName + "'s " + colour + " " + modelName
                + " (" + numberOfSeats + " seats)";
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }
}
