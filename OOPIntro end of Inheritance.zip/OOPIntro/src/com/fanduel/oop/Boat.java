package com.fanduel.oop;

public class Boat extends Vehicle {
    private boolean hasSundeck;

    public Boat(String ownerName, String colour, String modelName, int numberOfSeats) {
        super(ownerName, colour, modelName, numberOfSeats);
    }

    public boolean isHasSundeck() {
        return hasSundeck;
    }

    public void setHasSundeck(boolean hasSundeck) {
        this.hasSundeck = hasSundeck;
    }

    @Override
    public String toString() {
        return super.toString() + (hasSundeck?" with Sundeck!":" without Sundeck :<");
    }

    public void sellBoat(String newOwnerName){
        ownerName = newOwnerName;
    }
}
