package com.fanduel.inheritance;

public class ShoppingCart {
    public static void main(String args[]){ 
	// Instantiate a Shirt object and call display() on the object reference
        Shirt shirt = new Shirt(25.99, 'M', 'P');
        shirt.display();       
    }
}    
